package modelo;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;

public class ListaPaises  extends Exception{
    
    
    ArrayList <Pais> paises = new ArrayList();
    
    Pais Brazil = new Pais("Brazil", "kwanza", "Angoleño/a", "luanda", "portugues", 10.07);
    Pais Francia = new Pais("Francia", "Franco occidental", "senegales/sa", "Dakal", "frances", 5.56);
    Pais  EEUU = new Pais("EEUU", "cedi", "Ghanes/a", "Accra", "ingles", 630.9);
    Pais kenia = new Pais();
    Pais mali = new Pais();
            
    public void cargarDatosPaises(){
        
        
        kenia.setNombre("Kenia");
        kenia.setNombreMoneda("chelin keniano");
        kenia.setGentilicio("keniano/na");
        kenia.setCapital("nairobi");
        kenia.setIdioma("ingles");
        kenia.setPresioMomeda(32.19);
        
        mali.setNombre("Mali");
        mali.setNombreMoneda("Franco occidental");
        mali.setGentilicio("maliano/na");
        mali.setCapital("Bamako");
        mali.setIdioma("frances");
        mali.setPresioMomeda(5.56);

        
    }
    public  void cargarArraylist(){
        
        paises.add(Brazil);
        paises.add(Francia);
        paises.add(EEUU);
        paises.add(kenia);
        paises.add(mali);
        
        
    }
    
    public void llenarText(){
        try
        {
            FileWriter Archivo = new FileWriter("input.txt");
            PrintWriter pw = new PrintWriter(Archivo);
            
        Iterator it = paises.iterator();
        while (it.hasNext()) {
            Pais pais = (Pais)it.next();
            pw.println("pais :" + pais.getNombre());
            pw.println("capital :" + pais.getCapital());
            pw.println("gentilicio :" + pais.getGentilicio());
            pw.println("idioma :" + pais.getIdioma());
            pw.println("moneda que manejan :" +pais.getNombreMoneda());
            pw.println("presio de la moneda :" + pais.getPresioMomeda());
            pw.println("                                               ");
            
        }
        
                
            pw.close();
        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    
    public String buscarNombre(String nombre){
        String a= "";
        Iterator it = paises.iterator();
        while (it.hasNext()) {
            Pais pais = (Pais)it.next();
            if (nombre.equalsIgnoreCase(pais.getNombre())){
                a=pais.getNombre();
            }
        }
        return a;
    }
    public String buscarCapital(String nombre){
        String a= "";
        Iterator it = paises.iterator();
        while (it.hasNext()) {
            Pais pais = (Pais)it.next();
            if (nombre.equalsIgnoreCase(pais.getNombre())){
                a=pais.getCapital();
            }
        }
        return a;
    }
    public String buscarIdioma(String nombre){
        String a= "";
        Iterator it = paises.iterator();
        while (it.hasNext()) {
            Pais pais = (Pais)it.next();
            if (nombre.equalsIgnoreCase(pais.getNombre())){
                a=pais.getIdioma();
            }
        }
        return a;
    }
    public String buscarGentilico(String nombre){
        String a= "";
        Iterator it = paises.iterator();
        while (it.hasNext()) {
            Pais pais = (Pais)it.next();
            if (nombre.equalsIgnoreCase(pais.getNombre())){
                a=pais.getGentilicio();
            }
        }
        return a;
    }
    
    public String buscarMoneda(String nombre){
        String a= "";
        Iterator it = paises.iterator();
        while (it.hasNext()) {
            Pais pais = (Pais)it.next();
            if (nombre.equalsIgnoreCase(pais.getNombre())){
                a=pais.getNombreMoneda();
            }
        }
        return a;
    }
    
    DecimalFormat o = new DecimalFormat("#.00");
    
    
    public String calcularMoneda(String nombre ,double cantidad){
        double a=0;
        Iterator it = paises.iterator();
        while (it.hasNext()) {
            Pais pais = (Pais)it.next();
            if (nombre.equalsIgnoreCase(pais.getNombre())){
                a=Brazil.comvertidor(pais.getPresioMomeda(), cantidad);
            }
        }
        return (""+o.format(a));
    }
   public  String traductor(String idioma, String palabra){
      String a="  ";
      Iterator it = paises.iterator();
       while (it.hasNext()) {           
           Pais pais = (Pais)it.next();
           if (idioma.equalsIgnoreCase(pais.getIdioma())){
               a=Brazil.traductor(palabra);
           }
       }
       return a;
   }
   
   
}
