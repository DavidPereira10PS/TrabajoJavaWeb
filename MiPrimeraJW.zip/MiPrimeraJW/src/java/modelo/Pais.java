package modelo;

import static java.time.Clock.system;


public class Pais extends Africa implements ICambioTraductor{
    
   public Pais(){
       
   }
    
    public Pais(String nombre, String nombreMoneda, String gentilicio, String capital,String idioma, double presioMoneda){
        this.setNombre(nombre);        
        this.setNombreMoneda(nombreMoneda);        
        this.setPresioMomeda(presioMoneda);
        this.setCapital(capital);
        this.setGentilicio(gentilicio);
        this.setIdioma(idioma);
    }

    public String traductor(String palabra) {
        String traduccion = "nose encontro la palabra";
        try {
            
        switch(palabra){
            case "hola":
                if ("ingles".equalsIgnoreCase(getIdioma())){
                    traduccion = "hello"; 
                } else {
                    if ("portugues".equalsIgnoreCase(getIdioma())) {
                        traduccion="ola";
                    } else {
                        if ("frace".equalsIgnoreCase(getIdioma())){
                            traduccion="salut";
                        }
                    }
                }
            return traduccion;
            case "buenas":
                if ("ingles".equalsIgnoreCase(getIdioma())){
                    traduccion = "good"; 
                } else {
                    if ("portugues".equalsIgnoreCase(getIdioma())) {
                        traduccion="bom";
                    } else {
                        if ("frace".equalsIgnoreCase(getIdioma())){
                            traduccion="bon";
                        }
                    }
                }
            return  traduccion;
            case "foto":
                if ("ingles".equalsIgnoreCase(getIdioma())){
                    traduccion = "photo"; 
                } else {
                    if ("portugues".equalsIgnoreCase(getIdioma())) {
                        traduccion="imagen";
                    } else {
                        if ("frace".equalsIgnoreCase(getIdioma())){
                            traduccion="photo";
                        }
                    }
                }
            return  traduccion;
            case "computadora":
                if ("ingles".equalsIgnoreCase(getIdioma())){
                    traduccion = "compute"; 
                } else {
                    if ("portugues".equalsIgnoreCase(getIdioma())) {
                        traduccion="computador";
                    } else {
                        if ("frace".equalsIgnoreCase(getIdioma())){
                            traduccion="ordinateur";
                        }
                    }
                }
            return traduccion;
            case "lapiz":
                if ("ingles".equalsIgnoreCase(getIdioma())){
                    traduccion = "pencil"; 
                } else {
                    if ("portugues".equalsIgnoreCase(getIdioma())) {
                        traduccion="lapis";
                    } else {
                        if ("frace".equalsIgnoreCase(getIdioma())){
                            traduccion="crayon";
                        }
                    }
                }
            return traduccion;
        }
        
        
        } catch (NumberFormatException  e) {
            
            System.out.println("se deve ingresar un nuero."+e.getMessage());
        }
        return traduccion;
    }

    public double comvertidor(double precioMoneda, double cantidad) {
        double valor=0;
        try {
            valor = cantidad / precioMoneda;
               
        } catch (Exception e) {
            System.out.println("se deve ingresar un nuero."+e.getMessage());
        }
        return valor; 
    }
    

}
