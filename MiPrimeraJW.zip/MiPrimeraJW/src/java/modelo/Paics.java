package modelo;


public class Paics extends Exception implements ICambioTraductor{
     
    private String nombre;
    private String nombreMoneda;
    private String capital;
    private String gentilicio;
    private String idioma;
    private double presioMomeda;
    private String Palabra;

   
    public String getNombre() {
        return nombre;
    }

    
    public void setNombre(String nmbre) {
        this.nombre = nmbre;
    }

    
    public String getCapital() {
        return capital;
    }

    public void setCapital(String capital) {
        this.capital = capital;
    }

    
    public String getGentilicio() {
        return gentilicio;
    }

    
    public void setGentilicio(String gentilicio) {
        this.gentilicio = gentilicio;
    }

    
    public String getIdioma() {
        return idioma;
    }

   
    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }

    
    public double getPresioMomeda() {
        return presioMomeda;
    }

    
    public void setPresioMomeda(double presioMomeda) {
        this.presioMomeda = presioMomeda;
    }

    public String getNombreMoneda() {
        return nombreMoneda;
    }

    
    public void setNombreMoneda(String nombreMoneda) {
        this.nombreMoneda = nombreMoneda;
    }

    public double comvertidor(double precioMoneda, double cantidad) {
     
       return 0;
        
    }

    public String traductor(String palabra) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   

}
