
package modelo;


public interface iTraduc {
    
    public double convertidor(double precioMoneda,double cantidad);
    public String traductor(String palabra);
    
}
